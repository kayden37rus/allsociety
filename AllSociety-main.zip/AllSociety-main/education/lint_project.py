"""
Автономный анализатор кода Python с:
- Проверкой стиля, ошибок и сложности
- Русскоязычным выводом
- Оценкой качества кода
- Совместимостью со всеми версиями Pylint
"""

import os
import ast
import subprocess
from collections import defaultdict

class АнализаторКода:
    def __init__(self):
        self.результаты = []
        self.статистика = defaultdict(int)
        self.метрики = {
            'functions': 0,
            'classes': 0,
            'complexity': 0,
            'security': 0
        }
        
        self.перевод = {
            'fatal': 'КРИТИЧЕСКАЯ',
            'error': 'ОШИБКА',
            'warning': 'Предупреждение',
            'refactor': 'Совет',
            'convention': 'Стиль',
            'C0114': 'Отсутствует docstring модуля',
            'C0115': 'Отсутствует docstring класса',
            'C0116': 'Отсутствует docstring функции',
            'C0103': 'Нарушение именования (PEP 8)',
            'E1101': 'Несуществующий атрибут',
            'R1705': 'Лишний return',
            'W0612': 'Неиспользуемая переменная',
            'B101': 'Использование assert в продакшене'
        }

    def запустить_pylint(self, файл):
        """Запускает Pylint через subprocess"""
        try:
            результат = subprocess.run(
                ['pylint', '--output-format=text', файл],
                capture_output=True,
                text=True,
                check=False
            )
            return результат.stdout
        except Exception as e:
            print(f"⚠️ Ошибка при проверке {файл}: {str(e)}")
            return ""

    def разобрать_ошибку(self, строка):
        """Анализирует строку вывода Pylint"""
        if not строка.strip() or '***' in строка:
            return None
            
        части = строка.split(':')
        if len(части) < 4:
            return None
            
        файл = части[0].strip()
        строка_номер = части[1].strip()
        позиция = части[2].strip()
        сообщение = ':'.join(части[3:]).strip()
        
        # Извлекаем тип ошибки
        тип = 'unknown'
        код = 'XXXX'
        for key in self.перевод:
            if key in сообщение:
                тип = self.перевод.get(key.split('-')[0], 'unknown')
                код = key
                break
                
        return {
            'файл': файл,
            'строка': строка_номер,
            'позиция': позиция,
            'тип': тип,
            'код': код,
            'описание': сообщение
        }

    def проверить_ast(self, файл):
        """Анализирует структуру кода через AST"""
        try:
            with open(файл, 'r', encoding='utf-8') as f:
                tree = ast.parse(f.read())
                
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef):
                    self.метрики['functions'] += 1
                    # Проверка сложности
                    if len(node.body) > 10:
                        self.метрики['complexity'] += 1
                elif isinstance(node, ast.ClassDef):
                    self.метрики['classes'] += 1
                elif isinstance(node, ast.Assert):
                    self.метрики['security'] += 1
                    self.добавить_ошибку(
                        файл, node.lineno, 0,
                        'B101', 'Использование assert в продакшене'
                    )
        except Exception as e:
            print(f"⚠️ Ошибка AST анализа {файл}: {str(e)}")

    def добавить_ошибку(self, файл, строка, позиция, код, описание):
        """Добавляет ошибку в результаты"""
        тип = код[0] if len(код) > 0 else 'unknown'
        тип_рус = self.перевод.get(тип.lower(), тип.upper())
        
        запись = (
            f"{файл}:{строка}:{позиция} "
            f"[{тип_рус}] {описание} ({код})"
        )
        
        self.результаты.append(запись)
        self.статистика[тип.lower()] += 1

    def вывести_отчет(self):
        """Генерирует итоговый отчет"""
        print("\n" + "="*80)
        print("📊 ДЕТАЛИЗИРОВАННЫЙ ОТЧЕТ О КАЧЕСТВЕ КОДА")
        print("="*80 + "\n")
        
        if not self.результаты:
            print("✅ Код не содержит критических ошибок!")
        else:
            print("\n".join(self.результаты))
        
        print("\n" + "-"*80)
        print("📈 СТАТИСТИКА ОШИБОК:")
        print(f"🔴 Критические: {self.статистика['fatal']}")
        print(f"⛔ Ошибки: {self.статистика['error']}")
        print(f"⚠️ Предупреждения: {self.статистика['warning']}")
        print(f"💡 Советы: {self.статистика['refactor']}")
        print(f"📝 Стиль: {self.статистика['convention']}")
        
        print("\n🧮 МЕТРИКИ КОДА:")
        print(f"🧠 Сложные функции: {self.метрики['complexity']}")
        print(f"🔒 Проблемы безопасности: {self.метрики['security']}")
        print(f"📚 Всего функций: {self.метрики['functions']}")
        print(f"🏛 Всего классов: {self.метрики['classes']}")
        
        оценка = self.рассчитать_оценку()
        print("-"*80)
        print(f"\n⭐ ОБЩАЯ ОЦЕНКА КАЧЕСТВА: {оценка}/10\n")
    
    def рассчитать_оценку(self):
        """Вычисляет оценку качества кода"""
        base_score = 10
        
        # Штрафы за ошибки
        base_score -= self.статистика['fatal'] * 2
        base_score -= self.статистика['error'] * 1.5
        base_score -= self.статистика['warning'] * 0.5
        base_score -= self.метрики['complexity'] * 0.3
        base_score -= self.метрики['security'] * 2
        
        # Бонусы
        if self.статистика['convention'] < 3:
            base_score += 1
        if self.метрики['functions'] > 10:
            base_score += 0.5
            
        return max(1, min(10, int(base_score)))

def проверить_проект(директория="."):
    """Основная функция проверки проекта"""
    if not os.path.exists(директория):
        print(f"❌ Директория '{директория}' не существует!")
        return
    
    python_files = [
        os.path.join(root, f)
        for root, _, files in os.walk(директория)
        for f in files
        if f.endswith('.py') and not f.startswith('__')
    ]
    
    if not python_files:
        print("❌ Не найдено Python-файлов для проверки.")
        return
    
    print(f"🔍 Найдено {len(python_files)} файлов...")
    
    анализатор = АнализаторКода()
    
    for файл in python_files:
        # Проверка Pylint
        вывод = анализатор.запустить_pylint(файл)
        for строка in вывод.split('\n'):
            ошибка = анализатор.разобрать_ошибку(строка)
            if ошибка:
                анализатор.добавить_ошибку(
                    ошибка['файл'],
                    ошибка['строка'],
                    ошибка['позиция'],
                    ошибка['код'],
                    ошибка['описание']
                )
        
        # Дополнительный анализ AST
        анализатор.проверить_ast(файл)
    
    # Итоговый отчет
    анализатор.вывести_отчет()

if __name__ == "__main__":
    print("\n🚀 ЗАПУСК КОМПЛЕКСНОГО АНАЛИЗА КОДА...\n")
    проверить_проект(".")