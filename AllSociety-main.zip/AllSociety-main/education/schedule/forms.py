from django import forms
from .models import Schedule
#Создание форм (дня недели, времени и названия урока) для их заполнения и редактировани]
class ScheduleForm(forms.ModelForm):
    class Meta:
        model = Schedule
        fields = ['day_of_week', 'lesson_time', 'lesson_name']