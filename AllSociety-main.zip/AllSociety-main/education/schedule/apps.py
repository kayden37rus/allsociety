from django.apps import AppConfig

#название и сохранение таблицы как приложения для urls
class ScheduleConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'schedule'
